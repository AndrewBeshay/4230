Main file: rec_shapes.m

Feel free to change the code and insert in your project. Please do not forget cite the source:

Barrag�n, D. "Shape recognition using 2-D correlation", Retrieved January 29, 2015, from http://www.matpic.com.